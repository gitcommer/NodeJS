const express = require('express');
const expressLayouts = require('express-ejs-layouts');                          //1.using ejs -
const app = express();

// EJS
app.use(expressLayouts);                                                        //2.using ejs -
app.set('view engine', 'ejs');                                                  //3.using ejs -

// Routes
app.use('/', require('./routes/index'));                                        //call index.js in routes
app.use('/users', require('./routes/users'));

const PORT = process.env.PORT || 5000;

app.listen(PORT, console.log(`Server started on port ${PORT}`));
